
// index.js
Page({
  data: {
    statusBarHeight: 20,
    menuBottom: 0,
    scrollTop: 0,
    myBooks: [],
    recentBook: null,
    loading: true, // 【关键改动】默认设为 true，配合 WXML 中的 !loading 判断，防止空状态闪现
    isEditMode: false,
    selectedIds: [],
    selectedMap: {},
    uploadingId: null,
    myAdminIdentifier: 'o1O_E5FkoWifja25vrEog_u7WvCE',
  },

  onLoad() {
    const { statusBarHeight } = wx.getWindowInfo();
    const menuButton = wx.getMenuButtonBoundingClientRect();
    this.setData({ 
      statusBarHeight,
      menuBottom: menuButton.bottom + 5 
    });
  },

  onShow() {
    this.checkRecent();
    const app = getApp();
    if (app.globalData.userId) {
      this.fetchMyBooks();
    } else {
      app.userIdReadyCallback = (id) => { if (id) this.fetchMyBooks(); };
    }
  },

  // --- 1. 统一上传逻辑 (带配额与路径优化) ---

  uploadBook() {
    console.log('点击了上传按钮'); // 调试用
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      // 如果 extension 导致没反应，可以先试着去掉 extension 看看能不能拉起
      success: (res) => {
        const file = res.tempFiles[0];
        console.log('选择文件成功:', file.name);
        
        this.step1UploadToBucket(file.path, file.name, 'create', (resData) => {
          this.step2SaveToDatabase(resData.title, resData.url);
        });
      },
      fail: (err) => {
        console.log('选择文件失败或取消:', err);
      }
    });
  },

  doUploadCover(bookId, bookTitle) {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0];
        this.setData({ uploadingId: bookId });
        this.step1UploadToBucket(tempFilePath, bookTitle, 'update_cover', (resData) => {
          console.log('即将更新的封面URL字符串:', resData.url);
          this.step2UpdateCoverInDB(bookId, resData.url);
        });
      }
    });
  },

  step1UploadToBucket(filePath, bookTitle, action, onSuccess) {
    wx.showLoading({ title: '安全校验中...', mask: true });
    wx.uploadFile({
      url: 'https://rf3pmm2lnj.sealosbja.site/upload-file-to-bucket',
      filePath: filePath,
      name: 'file',
      header: { 'x-user-id': getApp().globalData.userId },
      formData: { bookTitle, action },
      success: (res) => {
        console.log('Step1 原始返回:', res.data);
        let data;
        try {
          data = JSON.parse(res.data);
        } catch (e) {
          console.error('Step1 JSON解析失败:', e);
          return wx.showToast({ title: '返回格式错误', icon: 'none' });
        }
        if (data && data.ok) {
          try {
            if (onSuccess) onSuccess(data); 
          } catch (callbackError) {
            console.error('Step1 回调执行报错:', callbackError);
            wx.showModal({ title: '后续逻辑错误', content: callbackError.message, showCancel: false });
          }
        } else {
          wx.showModal({ title: '上传拦截', content: data.msg || '未知错误', showCancel: false });
          wx.hideLoading();
        }
      },
      fail: (err) => {
        console.error('Step1 网络请求失败:', err);
        wx.hideLoading();
      }
    });
  },

  // --- 2. 数据库同步逻辑 ---

  step2SaveToDatabase(title, fileUrl) {
    wx.showLoading({ title: '同步书架...', mask: true });
    wx.request({
      url: 'https://rf3pmm2lnj.sealosbja.site/upload-private-book',
      method: 'POST',
      header: { 
        'x-user-id': getApp().globalData.userId,
        'content-type': 'application/json' 
      },
      data: { title, fileUrl, is_public: false },
      success: (res) => {
        if (res.data && res.data.ok) {
          wx.showToast({ title: '上架成功', icon: 'success' });
          this.fetchMyBooks(); 
        }
      },
      complete: () => wx.hideLoading()
    });
  },

  step2UpdateCoverInDB(bookId, coverUrl) {
    if (typeof coverUrl !== 'string') {
      console.error('逻辑错误：coverUrl 不是字符串！内容为:', coverUrl);
      return;
    }
    wx.showLoading({ title: '更新封面...', mask: true });
    wx.request({
      url: 'https://rf3pmm2lnj.sealosbja.site/update-book-info',
      method: 'POST',
      header: { 
        'x-user-id': getApp().globalData.userId,
        'content-type': 'application/json' 
      },
      data: { id: bookId, cover_url: coverUrl },
      success: (res) => {
        if (res.data && res.data.ok) {
          wx.showToast({ title: '封面已同步', icon: 'success' });
          this.fetchMyBooks(); 
        }
      },
      complete: () => {
        this.setData({ uploadingId: null });
        wx.hideLoading();
      }
    });
  },

  // --- 3. 基础业务逻辑 ---

  fetchMyBooks() {
    const userId = getApp().globalData.userId;
    if (!userId) return;
    
    // 允许手动触发，不再因为 loading 状态拦截请求
    this.setData({ loading: true });

    wx.request({
      url: 'https://rf3pmm2lnj.sealosbja.site/get-my-shelf',
      header: { 'x-user-id': userId },
      success: (res) => {
        const rawList = res.data.data || [];
        const colors = ['#7ea0b7', '#91a398', '#b39295', '#a99bbc', '#b5a489', '#89a4b5'];
        
        const books = rawList.map((book, idx) => {
          let displayCover = book.cover_url || '';
          if (displayCover && displayCover.includes('pafq4j2w-book-covers.objectstorageapi')) {
            displayCover = displayCover.replace('pafq4j2w-book-covers.objectstorageapi.bja.sealos.run', 'objectstorageapi.bja.sealos.run/pafq4j2w-book-covers');
          }
          if (displayCover) {
            displayCover = displayCover.includes('?') ? `${displayCover}&v=${Date.now()}` : `${displayCover}?v=${Date.now()}`;
          }
          return {
            ...book,
            cover_url: displayCover,
            bgColor: colors[idx % colors.length],
            progress_percent: Math.min(Math.floor(((book.progress || 0) / (book.total_size || 1)) * 100), 100)
          };
        });

        this.setData({ 
          myBooks: books,
          loading: false // 确保成功后关闭状态
        }, () => {
          this.validateRecentBook(books);
        });
      },
      fail: (err) => {
        console.error('获取书架失败:', err);
        this.setData({ loading: false });
      }
    });
  },

  // --- 4. 批量删除逻辑 ---

  handleBatchDelete() {
    const { selectedIds } = this.data;
    if (selectedIds.length === 0) return wx.showToast({ title: '请先选择书籍', icon: 'none' });
    wx.showModal({
      title: '确认删除',
      content: `确定要彻底移除这 ${selectedIds.length} 本书吗？`,
      confirmColor: '#ff4d4f',
      success: (res) => {
        if (res.confirm) this.executeDeleteRequest(selectedIds);
      }
    });
  },

  executeDeleteRequest(ids) {
    wx.showLoading({ title: '正在清理...', mask: true });
    wx.request({
      url: 'https://rf3pmm2lnj.sealosbja.site/delete-book-batch',
      method: 'POST',
      header: { 
        'x-user-id': getApp().globalData.userId,
        'content-type': 'application/json' 
      },
      data: { bookIds: ids },
      success: (res) => {
        if (res.data && res.data.ok) {
          const lastRead = wx.getStorageSync('last_read');
          if (lastRead && ids.includes(lastRead._id)) {
            wx.removeStorageSync('last_read');
            this.setData({ recentBook: null });
          }
          wx.showToast({ title: '已成功移除', icon: 'success' });
          this.exitEditMode();
          this.fetchMyBooks(); 
        }
      },
      complete: () => wx.hideLoading()
    });
  },

  // --- 5. 交互与状态管理 ---

  onLongPressCover(e) {
    if (this.data.isEditMode) return;
    wx.vibrateShort({ type: 'medium' });
    const userId = getApp().globalData.userId;
    const book = e.currentTarget.dataset.item;
    
    if (userId === this.data.myAdminIdentifier) {
      wx.showActionSheet({
        itemList: ['更新图书封面', '开启管理模式'],
        success: (res) => {
          if (res.tapIndex === 1) this.enterEditMode();
          else if (res.tapIndex === 0) this.doUploadCover(book._id, book.title);
        }
      });
    } else {
      this.enterEditMode();
    }
  },

  toggleSelect(id) {
    let { selectedMap, selectedIds } = this.data;
    if (selectedMap[id]) {
      delete selectedMap[id];
      selectedIds = selectedIds.filter(v => v !== id);
    } else {
      selectedMap[id] = true;
      selectedIds.push(id);
    }
    this.setData({ selectedMap, selectedIds });
    wx.vibrateShort({ type: 'light' });
  },

  onBookTap(e) {
    const book = e.currentTarget.dataset.item;
    if (this.data.isEditMode) this.toggleSelect(book._id);
    else this.tapBook(e);
  },

  tapBook(e) {
    const book = e.currentTarget.dataset.item;
    wx.vibrateShort({ type: 'light' });
    wx.setStorageSync('last_read', book);
    wx.navigateTo({ url: `/pages/player/player?id=${book._id}&title=${encodeURIComponent(book.title)}` });
  },

  validateRecentBook(currentBooks) {
    const lastRead = wx.getStorageSync('last_read');
    if (!lastRead) {
      this.setData({ recentBook: null });
      return;
    }
    const isExist = currentBooks.some(book => book._id === lastRead._id);
    if (!isExist) {
      wx.removeStorageSync('last_read');
      this.setData({ recentBook: null });
    } else {
      this.checkRecent(); 
    }
  },

  checkRecent() {
    const last = wx.getStorageSync('last_read');
    if (last) {
      const currentPos = wx.getStorageSync('pos_' + last._id) || 0;
      let progressText = currentPos > 0 ? `已读 ${Math.floor(currentPos / 1024)} KB` : '尚未开始';
      this.setData({ recentBook: { ...last, progressStatus: progressText } });
    }
  },

  enterEditMode() {
    if (this.data.isEditMode) return;
    wx.vibrateShort({ type: 'medium' });
    this.setData({ isEditMode: true, selectedIds: [], selectedMap: {}, scrollTop: 0 });
  },

  exitEditMode() {
    this.setData({ isEditMode: false, selectedIds: [], selectedMap: {} });
  },

  goToWarehouse() { wx.navigateTo({ url: '/pages/warehouse/warehouse' }); }
});