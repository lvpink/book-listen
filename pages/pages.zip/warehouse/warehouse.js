根据你的要求，我将权限校验前置到了 executeUploadTask 的入口处，并整合了文件名解析逻辑。

以下是修改后的完整 warehouse.js 代码。

JavaScript

// 限制常量
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 文档建议限制在 50MB
const ALLOWED_EXTENSIONS = ['txt', 'pdf', 'epub']; // 仅限文档格式

Page({
  data: {
    isAdmin: false,
    myAdminIdentifier: 'o1O_E5FkoWifja25vrEog_u7WvCE', // 管理员特定标识
    isSearching: false,
    uploading: false,
    statusBarHeight: 20,
    allBooks: [],
    displayBooks: []
  },

  onLoad() {
    const sys = wx.getSystemInfoSync();
    const userId = getApp().globalData.userId;
    this.setData({
      statusBarHeight: sys.statusBarHeight,
      isAdmin: userId === this.data.myAdminIdentifier
    });
    this.fetchWarehouseBooks();
  },

  fetchWarehouseBooks() {
    wx.request({
      url: 'https://rf3pmm2lnj.sealosbja.site/get-my-shelf',
      header: {
        'x-user-id': 'PUBLIC_USER'
      },
      success: (res) => {
        const books = res.data.data || [];
        this.setData({
          allBooks: books,
          displayBooks: books
        });
      }
    });
  },

  // ★ 批量上传入口 ★
  handleBatchUploadPublic() {
    // 1. 点击时立即进行初步权限判定
    if (!this.data.isAdmin) {
      wx.showModal({
        title: '权限拒绝',
        content: '只有管理员可以操作公共仓库',
        showCancel: false
      });
      return;
    }

    if (this.data.uploading) return;

    wx.chooseMessageFile({
      count: 10,
      type: 'file',
      success: async (res) => {
        const originalFiles = res.tempFiles;
        let successCount = 0;
        let failList = [];
        let skipList = [];

        // 2. 前置文件过滤
        const validFiles = originalFiles.filter(file => {
          const ext = file.name.split('.').pop().toLowerCase();
          const isTypeOk = ALLOWED_EXTENSIONS.includes(ext);
          const isSizeOk = file.size <= MAX_FILE_SIZE;

          if (!isTypeOk) skipList.push(`${file.name}(格式不支持)`);
          else if (!isSizeOk) skipList.push(`${file.name}(超过50MB)`);

          return isTypeOk && isSizeOk;
        });

        if (validFiles.length === 0) {
          return wx.showModal({
            title: '校验未通过',
            content: skipList.join('\n'),
            showCancel: false
          });
        }

        this.setData({ uploading: true });
        wx.showLoading({ title: '准备上传...', mask: true });

        for (let i = 0; i < validFiles.length; i++) {
          wx.showLoading({
            title: `同步(${i + 1}/${validFiles.length})`,
            mask: true
          });
          try {
            await this.executeUploadTask(validFiles[i]);
            successCount++;
          } catch (err) {
            failList.push(`${validFiles[i].name}: ${err}`);
          }
        }

        this.setData({ uploading: false });
        wx.hideLoading();

        this.showUploadReport(successCount, failList, skipList);
        this.fetchWarehouseBooks();
      }
    });
  },

  // ★ 核心任务执行：前置权限校验 + 文件名解析 ★
  executeUploadTask(file) {
    return new Promise((resolve, reject) => {
      // --- 第一道防线：进入方法立即校验权限 ---
      const userId = getApp().globalData.userId;
      if (userId !== this.data.myAdminIdentifier) {
        return reject('非管理员，禁止上传');
      }

      // --- 解析文件名：提取书名、作者、分类 ---
      const info = this.parseFileInfo(file.name);

      // Step 1: 上传到文档桶
      wx.uploadFile({
        url: 'https://rf3pmm2lnj.sealosbja.site/upload-file-to-bucket',
        filePath: file.path,
        name: 'file',
        header: {
          'x-user-id': userId
        },
        formData: {
          bookTitle: file.name,
          action: 'create_public' // 告知后端去处理封面并存入封面桶
        },
        success: (uRes) => {
          let uData;
          try {
            uData = JSON.parse(uRes.data);
          } catch (e) {
            return reject('服务器响应解析失败');
          }

          if (!uData.ok) return reject(uData.msg);

          // Step 2: 入库公共仓库接口
          wx.request({
            url: 'https://rf3pmm2lnj.sealosbja.site/upload-public-book',
            method: 'POST',
            header: {
              'x-user-id': userId,
              'content-type': 'application/json'
            },
            data: {
              title: info.title,
              author: info.author,
              category: info.extension, // 使用后缀名作为分类
              fileUrl: uData.url,
              coverUrl: uData.coverUrl // 后端处理完封面后返回的封面桶地址
            },
            success: (sRes) => {
              if (sRes.data && sRes.data.ok) resolve();
              else reject(sRes.data.msg || '入库失败');
            },
            fail: () => reject('网络请求失败')
          });
        },
        fail: () => reject('上传文件请求失败')
      });
    });
  },

  // 解析文件名助手
  parseFileInfo(fileName) {
    const dotIndex = fileName.lastIndexOf('.');
    const extension = fileName.substring(dotIndex + 1).toLowerCase();
    const nameWithoutExt = fileName.substring(0, dotIndex);

    let title = nameWithoutExt;
    let author = '佚名';

    // 匹配 "书名-作者" 格式
    if (nameWithoutExt.includes('-')) {
      const parts = nameWithoutExt.split('-');
      // 考虑到可能书名里也有连字符，取最后一个连字符分割或者第一个
      // 这里采用第一个连字符分割：书名-作者
      title = parts[0].trim();
      author = parts[1].trim();
    }

    return { title, author, extension };
  },

  showUploadReport(success, fails, skips) {
    let content = `成功: ${success} 本\n`;
    if (fails.length > 0) content += `失败: ${fails.length} 本\n`;
    if (skips.length > 0) content += `跳过: ${skips.length} 本\n`;

    if (fails.length > 0 || skips.length > 0) {
      wx.showModal({
        title: '任务报告',
        content: content + `\n详情:\n${skips.concat(fails).join('\n')}`,
        showCancel: false
      });
    } else {
      wx.showToast({
        title: `成功上架${success}本`,
        icon: 'success'
      });
    }
  },

  // 加入书架：从仓库同步到私人收藏
  addToMyShelf(e) {
    const book = e.currentTarget.dataset.item;
    wx.showLoading({ title: '入库中...' });
    wx.request({
      url: 'https://rf3pmm2lnj.sealosbja.site/upload-private-book',
      method: 'POST',
      header: {
        'x-user-id': getApp().globalData.userId,
        'content-type': 'application/json'
      },
      data: {
        title: book.title,
        fileUrl: book.file_url || book.url,
        is_public: false
      },
      success: (res) => {
        wx.showToast({
          title: res.data.ok ? '已加入书架' : (res.data.msg || '失败'),
          icon: res.data.ok ? 'success' : 'none'
        });
      }
    });
  },

  enableSearch() { this.setData({ isSearching: true }); },
  disableSearch() { this.setData({ isSearching: false, displayBooks: this.data.allBooks }); },
  onSearch(e) {
    const val = e.detail.value.toLowerCase();
    const filtered = this.data.allBooks.filter(book =>
      book.title.toLowerCase().includes(val) || (book.author && book.author.toLowerCase().includes(val))
    );
    this.setData({ displayBooks: filtered });
  }
});